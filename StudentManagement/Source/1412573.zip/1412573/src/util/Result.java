package util;

public class Result {
    public interface ResponseReceiver {
        void receiveResult(Object obj);
    }
}
